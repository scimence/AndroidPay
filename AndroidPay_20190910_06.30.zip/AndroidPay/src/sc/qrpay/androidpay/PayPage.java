
package sc.qrpay.androidpay;

import sc.qrpay.function.ActivityComponent;
import sc.qrpay.function.Configer;
import sc.qrpay.function.Preference;
import sc.qrpay.function.ThreadTool;
import sc.qrpay.function.ThreadTool.ThreadPram;
import sc.qrpay.function.Tools;
import sc.qrpay.function.WebTool;
import sc.qrpay.sdk.SDK;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Toast;


public class PayPage extends ActivityComponent
{
	String		ProductName;
	String		ProductMoney;
	String		Reserve;
	String		Author;
	
	int			payType		= 1;	// 记录当前选中的方式
	Preference	localInfo;
	
	String		DeviceId	= "";
	String		AppName		= "";
	
	/** 界面显示设置 */
	@Override
	public void Init(Bundle savedInstanceState)
	{
		this.setContentView("pay_layout_pay");
		
		// 获取支付相关参数信息
		DeviceId = Tools.getDeviceId(this);
		AppName = Tools.getAppName(this);
		
		Intent intent = this.getIntent();
		ProductName = intent.getStringExtra("ProductName");
		ProductMoney = intent.getStringExtra("ProductMoney");
		Reserve = intent.getStringExtra("Reserve");
		Author = intent.getStringExtra("Author");
		
		setProductInfo();		// 设置显示的商品信息
		
		localInfo = new Preference(this, "localInfo");
		loadPrePayType();		// 设置支付类型
	}
	
	/** 界面控件点击响应逻辑 */
	@Override
	public void Click(String viewId)
	{
		if (viewId.equals("pay_more_paytype"))				// 更多支付方式
		{
			TextView("pay_more_paytype").setVisibility(View.INVISIBLE);
			LinearLayout("pay_iteam_others").setVisibility(View.VISIBLE);	// 显示其他支付方式
		}
		else if (viewId.equals("pay_btn"))
		{
			localInfo.put("LastPayType", payType + "");		// 记录当前选中的支付方式
			payLogic();
		}
		else if (viewId.startsWith("pay_iteam") || viewId.startsWith("pay_radioButton"))
		{
			setPayType(viewId);
		}
		else if (viewId.equals("pay_dialog_header_back"))
		{
			this.finish();
		}
	}
	
	/** 设置商品信息 */
	private void setProductInfo()
	{
		TextView("pay_app_name").setText(AppName);
		TextView("pay_product").setText(ProductName);
		TextView("pay_money").setText("￥ " + ProductMoney);
		
	}
	
	/** 载入之前的支付类型设置 */
	private void loadPrePayType()
	{
		String LastPayType = localInfo.get("LastPayType");
		if (!LastPayType.equals("")) payType = Integer.parseInt(LastPayType);
		
		setPayType(payType + "");	// 设置为对应的支付类型
		if (payType > 3) Click("pay_more_paytype");	// 显示更多支付类型
	}
	
	/** 设置当前选中的支付方式 */
	private void setPayType(String viewId)
	{
		for (int i = 1; i <= 6; i++)
		{
			boolean isSelect = (viewId.equals("pay_iteam" + i) || viewId.equals("pay_radioButton" + i) || viewId.equals(i + ""));
			
			RadioButton("pay_radioButton" + i).setChecked(isSelect);
			if (isSelect) payType = i;
		}
	}
	
	// 预下单，获取订单号：
	// http://www.scimence.club:8002/pages/pay.aspx?TYPE=PreOrder&machinCode=机器码1&soft=easyIcon软件&product=注册0.1元&money=0.1&ext=author(test852)author;其它信息
	// 显示，预下单二维码： http://www.scimence.club:8002/pages/pay.aspx?TYPE=ShowPreOrder&preOrderId=100
	// 查询订单支付结果： http://www.scimence.club:8002/pages/pay.aspx?TYPE=OrderResult&preOrderId=100
	
	// String ProductName;
	// String ProductMoney;
	// String Reserve;
	
	/** 支付逻辑 */
	private void payLogic()
	{
//		String Url0 = "http://www.scimence.club:8002/P/index3.html";
//		Url0 = "alipayqr://platformapi/startapp?saId=10000007&qrcode=" + Url0;
//		OpenLink(this, Url0, "com.eg.android.AlipayGphone");
//		if(true) return;
		
		String orderId = CreateOrderId();
		if (orderId.equals("")) return;
		
		if (payType == 1)
		{
			if (Tools.isPkgInstalled(this, "com.eg.android.AlipayGphone"))
			{
				//				http://www.scimence.club:8002/pages/pay.aspx?TYPE=CreateOrder&preOrderId=554
				
//				String urlParam = "TYPE=CreateOrder&preOrderId=" + orderId + "&PayType=Ali";
				//				String Url = "alipayqr://platformapi/startapp?saId=10000007&qrcode=" + Configer.Url("/pages/pay.aspx", urlParam);
				//				
				//				OpenLink(this, Url);
				
//				String Url = Configer.Url("/pages/pay.aspx", urlParam);
//				Url = "alipayqr://platformapi/startapp?saId=10000007&qrcode=" +Url;
//				
//				20000001
//				10000007
//				Url = "alipayqr://platformapi/startapp?saId=10000007&qrcode=HTTPS://QR.ALIPAY.COM/FKX07952VIKS4E9BWMRD9E";
//				Url = "alipayqr://platformapi/startapp?saId=10000007&qrcode=http://60.205.185.168:8002/pageHB/HB.aspx";
				
				String Url = Configer.Url("/P/R.aspx", "a=" + orderId);
				Url = "alipayqr://platformapi/startapp?saId=10000007&qrcode=" + Url;
				
				OpenLink(this, Url, "com.eg.android.AlipayGphone");
//				PayPage_WebView.Show(this, Url);
				
//				WebView webView= new WebView(this);
//				webView.loadUrl(Url);
				
				//				String payParam = "TYPE=PreOrder&machinCode=Android:" + DeviceId + "&soft=App:" + AppName + "&product=" + ProductName + "&money=" + ProductMoney
				//						+ "&ext=author(" + Author + ")author;" + Reserve;
				//				String urlParam = "PayType=Ali" + "&" + payParam + "&preOrderId=" + orderId;
				//				String Url = Configer.Url("/pages/Order.aspx", urlParam);
				//				
				//				OpenLink(this, Url);
			}
			else
			{
				String urlParam = "TYPE=ShowPreOrder&preOrderId=" + orderId;
				String Url = Configer.Url("/pages/pay.aspx", urlParam);
				Tools.showToast(this, Url);
				
				// String Url = "http://www.wwei.cn/qrcode-viewfile?type=qrcode_text&k=8cvXz&hash=79b54fb155a9f909f0c964deddda11f0&timeout=1547775825&size=100";
				PayPage_WebView.Show(this, Url);
			}
		}
		else
		{
			Toast.makeText(this, "暂不支持该支付方式！", Toast.LENGTH_SHORT).show();
		}
		
		CheckPayResult(this);
	}
	
	/** 请求支付获取订单号 */
	private String CreateOrderId()
	{
		String payParam = "TYPE=PreOrder&machinCode=Android:" + DeviceId + "&soft=App:" + AppName + "&product=" + ProductName + "&money=" + ProductMoney
				+ "&ext=author(" + Author + ")author;" + Reserve;
		
		// 创建订单
		String OrderUrl = Configer.Url("/pages/pay.aspx", payParam);
		String data = WebTool.GetString(OrderUrl);					// Result(535)Result
		String OrderId = Tools.getNodeData(data, "Result", false);
		
		if (OrderId.trim().equals("") || OrderId.equals("fail"))
		{
			Tools.showToast(this, "服务器下单失败，请稍后再试。");
			return "";
		}
		else
		{
			OrderInfo.put(OrderId, payParam);	// 记录订单信息
			OrderResult.put(OrderId, "0");		// 记录订单查询统计次数
		}
		
		return OrderId;
	}
	
	/** 打开指定的链接地址 */
	private void OpenLink(Context context, String Url, String configPackageName)
	{
		Uri uri = Uri.parse(Url);
		Intent intent = new Intent(Intent.ACTION_VIEW, uri);
//		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setPackage(configPackageName);
		context.startActivity(intent);
	}
	
	
	/** 打开指定的链接地址 */
	private void OpenLink2(Context context/*, String Url*/)
	{
		String configPackageName = "com.eg.android.AlipayGphone";
		String className = "com.alipay.mobile.quinox.LauncherActivity.alias";
		
//		Uri uri = Uri.parse(Url);
//		Intent intent = new Intent(Intent.ACTION_VIEW, uri);
		Intent intent = new Intent();
//		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setClassName(configPackageName, className);
		intent.putExtra("actionType", "scan");
//		intent.setPackage(configPackageName);
		context.startActivity(intent);
	}
	// -----------
	
	/** 调用支付
	 * 
	 * @param context
	 * @param ProductName 	商品名称
	 * @param ProductMoney 	支付金额（元）， 如：1.99
	 * @param Reserve 		自定义字段，查询支付结果时会原样返还
	 * @param Author		应用所有者对应帐号名
	 *  */
	public static void Show(Context context, String ProductName, String ProductMoney, String Reserve, String Author)
	{
		ProductMoney = Tools.FormatMoneyStr(ProductMoney);
		
		if (ProductMoney.equals("0.00"))
			Tools.showToast(context, "不支持该金额,ProductMoney -> " + ProductMoney + "！");
		else if (Author == null || Author.equals(""))
			Tools.showToast(context, "Author字段不可为空！");
		else
		{
			Intent intent = new Intent(context, PayPage.class);
			intent.putExtra("ProductName", ProductName);
			intent.putExtra("ProductMoney", ProductMoney);
			intent.putExtra("Reserve", Reserve);
			intent.putExtra("Author", Author);
			
			context.startActivity(intent);
		}
	}
	
	/** 记录订单信息 */
	private static Preference	OrderInfo;
	private static Preference	OrderResult;
	private static int			CheckPayConter	= 0;
	
	/** 检测支付结果, count重复检测次数 */
	public static void CheckPayResult(Context context)
	{
		if (SDK.call == null) return;	// 无回调处理逻辑，则不查询支付结果
			
		if (OrderInfo == null) OrderInfo = new Preference(context, "OrderInfo");
		if (OrderResult == null) OrderResult = new Preference(context, "OrderResult");
		
		if (CheckPayConter <= 0)
		{
			CheckPayConter = 4;
			ThreadPram param = new ThreadPram()
			{
				@Override
				public void Function()
				{
					while (CheckPayConter > 0)
					{
						CheckPayConter--;
						try
						{
							Thread.sleep(30000);
						}
						catch (InterruptedException e)
						{
							e.printStackTrace();
						}
						
						CheckProcess();
					}
				}
			};
			ThreadTool.RunInCachedThread(param);
		}
		else CheckPayConter = 4;
	}
	
	// 检测所有订单支付结果
	private static void CheckProcess()
	{
		if (SDK.call == null) return;
		
		boolean isFail = false;
		for (String orderId : OrderInfo.Keys())
		{
			try
			{
				// 查询订单支付结果： http://www.scimence.club:8002/pages/pay.aspx?TYPE=OrderResult&preOrderId=100
				String UrlParam = "TYPE=OrderResult&preOrderId=" + orderId;
				String Url = Configer.Url("/pages/pay.aspx", UrlParam);
				
				String data = WebTool.GetString(Url);
				
				// 校验订单返回信息
				String PayParam = OrderInfo.get(orderId);
				boolean success = (!(data.contains("fail") || data.trim().equals("")));
				
				int time = Integer.parseInt(OrderResult.get(orderId));	// 获取订单查询次数
				OrderResult.put(orderId, (time + 1) + "");				// 记录订单查询统计次数
				
				if (success)
				{
					if (SDK.call != null) SDK.call.OnSuccess(data);
					
					OrderInfo.remove(orderId);
					OrderResult.remove(orderId);
				}
				else if (CheckPayConter == 0)
				{
					if (time >= 20)		// 多次查询，超出查询次数限制的订单自动删除
					{
						isFail = true;
						OrderInfo.remove(orderId);
						OrderResult.remove(orderId);
					}
				}
			}
			catch (Exception ex)
			{}
		}
		
		if (isFail)
		{
			if (SDK.call != null) SDK.call.Onfail();
		}
	}
}
