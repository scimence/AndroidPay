
package sc.qrpay.sdk;

public interface CallBack
{
	// 成功
	public void OnSuccess(String ProductName, String ProductMoney,  String reserve);
	
	// 失败
	public void Onfail();
}
