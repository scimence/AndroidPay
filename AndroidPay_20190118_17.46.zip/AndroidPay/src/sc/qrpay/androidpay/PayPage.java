
package sc.qrpay.androidpay;

import sc.qrpay.function.ActivityComponent;
import sc.qrpay.function.Configer;
import sc.qrpay.function.Preference;
import sc.qrpay.function.ThreadTool;
import sc.qrpay.function.ThreadTool.ThreadPram;
import sc.qrpay.function.Tools;
import sc.qrpay.function.WebTool;
import sc.qrpay.sdk.SDK;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;


public class PayPage extends ActivityComponent
{
	String ProductName;
	String ProductMoney;
	String Reserve;
	String Author;
	
	int payType = 1;	// 记录当前选中的方式
	Preference localInfo;
	
	String DeviceId = "";
	String AppName = "";
	
	/** 界面显示设置 */
	@Override
	public void Init(Bundle savedInstanceState)
	{
		this.setContentView("pay_layout_pay");
		
		// 获取支付相关参数信息
		DeviceId = Tools.getDeviceId(this);
		AppName = Tools.getAppName(this);
		
		Intent intent = this.getIntent();
		ProductName = intent.getStringExtra("ProductName");
		ProductMoney = intent.getStringExtra("ProductMoney");
		Reserve = intent.getStringExtra("Reserve");
		Author = intent.getStringExtra("Author");
		
		setProductInfo();		// 设置显示的商品信息
		
		localInfo = new Preference(this, "localInfo");
		loadPrePayType();		// 设置支付类型
	}
	
	/** 界面控件点击响应逻辑 */
	@Override
	public void Click(String viewId)
	{
		if (viewId.equals("pay_more_paytype"))				// 更多支付方式
		{
			TextView("pay_more_paytype").setVisibility(View.INVISIBLE);
			LinearLayout("pay_iteam_others").setVisibility(View.VISIBLE);	// 显示其他支付方式
		}
		else if (viewId.equals("pay_btn"))
		{
			localInfo.put("LastPayType", payType + "");		// 记录当前选中的支付方式
			payLogic();
		}
		else if (viewId.startsWith("pay_iteam") || viewId.startsWith("pay_radioButton"))
		{
			setPayType(viewId);
		}
		else if (viewId.equals("pay_dialog_header_back"))
		{
			this.finish();
		}
	}
	
	/** 设置商品信息 */
	private void setProductInfo()
	{
		TextView("pay_app_name").setText(AppName);
		TextView("pay_product").setText(ProductName);
		TextView("pay_money").setText("￥ " + ProductMoney);
		
	}
	
	/** 载入之前的支付类型设置 */
	private void loadPrePayType()
	{
		String LastPayType = localInfo.get("LastPayType");
		if (!LastPayType.equals("")) payType = Integer.parseInt(LastPayType);
		
		setPayType(payType + "");	// 设置为对应的支付类型
		if (payType > 3) Click("pay_more_paytype");	// 显示更多支付类型
	}
	
	/** 设置当前选中的支付方式 */
	private void setPayType(String viewId)
	{
		for (int i = 1; i <= 6; i++)
		{
			boolean isSelect = (viewId.equals("pay_iteam" + i) || viewId.equals("pay_radioButton" + i) || viewId.equals(i + ""));
			
			RadioButton("pay_radioButton" + i).setChecked(isSelect);
			if (isSelect) payType = i;
		}
	}
	
	// 预下单，获取订单号：
	// http://www.scimence.club:8002/pages/pay.aspx?TYPE=PreOrder&machinCode=机器码1&soft=easyIcon软件&product=注册0.1元&money=0.1&ext=author(test852)author;其它信息
	// 显示，预下单二维码： http://www.scimence.club:8002/pages/pay.aspx?TYPE=ShowPreOrder&preOrderId=100
	// 查询订单支付结果： http://www.scimence.club:8002/pages/pay.aspx?TYPE=OrderResult&preOrderId=100
	
	// String ProductName;
	// String ProductMoney;
	// String Reserve;
	
	/** 支付逻辑 */
	private void payLogic()
	{
		String orderId = CreateOrderId();
		if (orderId.equals("")) return;
		
		if (payType == 1)
		{
			if (Tools.isPkgInstalled(this, "com.eg.android.AlipayGphone"))
			{	
				
			}
			else
			{
				String urlParam = "TYPE=ShowPreOrder&preOrderId=" + orderId;
				String Url = Configer.Url("/pages/pay.aspx", urlParam);
				Tools.showToast(this, Url);
				
				// String Url = "http://www.wwei.cn/qrcode-viewfile?type=qrcode_text&k=8cvXz&hash=79b54fb155a9f909f0c964deddda11f0&timeout=1547775825&size=100";
				PayPage_WebView.Show(this, Url);
			}
		}
		else
		{
			Toast.makeText(this, "暂不支持该支付方式！", Toast.LENGTH_SHORT).show();
		}
		
		CheckPayResult(this);
	}
	
	/** 请求支付获取订单号 */
	private String CreateOrderId()
	{
		String payParam = "TYPE=PreOrder&machinCode=Android:" + DeviceId + "&soft=App:" + AppName + "&product=" + ProductName + "&money=" + ProductMoney
				+ "&ext=author(" + Author + ")author;" + Reserve;
		
		// 创建订单
		String OrderUrl = Configer.Url("/pages/pay.aspx", payParam);
		String data = WebTool.GetString(OrderUrl);					// Result(535)Result
		String OrderId = Tools.getNodeData(data, "Result", false);	
		
		if (OrderId.trim().equals("") || OrderId.equals("fail"))
		{
			Tools.showToast(this, "服务器下单失败，请稍后再试。");
			return "";
		}
		else
		{
			OrderInfo.put(OrderId, payParam);	// 记录订单信息
			OrderResult.put(OrderId, "0");		// 记录订单查询统计次数
		}
		
		return OrderId;
	}
	
	// -----------
	
	/** 调用支付
	 * 
	 * @param context
	 * @param ProductName 商品名称
	 * @param ProductMoney 支付金额（元）， 如：1.99
	 * @param Reserve 自定义字段，查询支付结果时会原样返还
	 * @param Author 应用所有者对应帐号名 */
	public static void Show(Context context, String ProductName, String ProductMoney, String Reserve, String Author)
	{
		CheckPayResult(context);	// 调用支付开始,就开始进行支付结果检测
		
		ProductMoney = Tools.FormatMoneyStr(ProductMoney);
		
		if (ProductMoney.equals("0.00"))
			Tools.showToast(context, "不支持该金额,ProductMoney -> " + ProductMoney + "！");
		else if (Author == null || Author.equals(""))
			Tools.showToast(context, "Author字段不可为空！");
		else
		{
			Intent intent = new Intent(context, PayPage.class);
			intent.putExtra("ProductName", ProductName);
			intent.putExtra("ProductMoney", ProductMoney);
			intent.putExtra("Reserve", Reserve);
			intent.putExtra("Author", Author);
			
			context.startActivity(intent);
		}
	}
	
	/** 记录订单信息 */
	private static Preference OrderInfo;
	private static Preference OrderResult;
	private static int CheckPayConter = 0;
	
	/** 检测支付结果, count重复检测次数 */
	private static void CheckPayResult(Context context)
	{
		if (OrderInfo == null) OrderInfo = new Preference(context, "OrderInfo");
		if (OrderResult == null) OrderResult = new Preference(context, "OrderResult");
		
		if (CheckPayConter <= 0)
		{
			CheckPayConter = 4;
			ThreadPram param = new ThreadPram()
			{
				@Override
				public void Function()
				{
					while (CheckPayConter > 0)
					{
						CheckPayConter--;
						try
						{
							Thread.sleep(30000);
						}
						catch (InterruptedException e)
						{
							e.printStackTrace();
						}
						
						CheckProcess();
					}
				}
			};
			ThreadTool.RunInCachedThread(param);
		}
		else CheckPayConter = 4;
	}
	
	// 检测所有订单支付结果
	private static void CheckProcess()
	{
		boolean isfail = false;
		for (String orderId : OrderInfo.Keys())
		{
			try
			{
				// 查询订单支付结果： http://www.scimence.club:8002/pages/pay.aspx?TYPE=OrderResult&preOrderId=100
				String UrlParam = "TYPE=OrderResult&preOrderId=" + orderId;
				String Url = Configer.Url("/pages/pay.aspx", UrlParam);
				
				String data = WebTool.GetString(Url);
				
				// 校验订单返回信息
				String PayParam = OrderInfo.get(orderId);
				boolean success = (!(data.contains("fail") || data.trim().equals("")));
				if (!success) isfail = true;
				
				if (SDK.call != null)
				{
					if (success)
					{
						SDK.call.OnSuccess(data);
						
						OrderInfo.remove(orderId);
						OrderResult.remove(orderId);
					}
					else if (CheckPayConter == 0)
					{
						int time = Integer.parseInt(OrderResult.get(orderId));
						if (time > 30)		// 多次查询，超出查询次数限制的订单自动删除
						{
							OrderInfo.remove(orderId);
							OrderResult.remove(orderId);
						}
					}
				}
			}
			catch (Exception ex)
			{	
				
			}
		}
		
		if (SDK.call != null) SDK.call.Onfail();
	}
}
