
package sc.qrpay.androidpay;

import sc.qrpay.function.Tools;
import sc.qrpay.sdk.CallBack;
import sc.qrpay.sdk.SDK;
import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;


public class MainActivity extends Activity
{
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.pay_activity_main);
	}
	
	public void onClick(View view)
	{
		CallBack call = new CallBack()
		{

			@Override
			public void OnSuccess(String reserve)
			{
				Tools.showToast(MainActivity.this, "支付成功" + reserve );
			}
			
			@Override
			public void Onfail()
			{
				Tools.showToast(MainActivity.this, "支付失败" );
			}
			
		};
		
		SDK.Pay("ProductName", "0.01", "Reserve", "Author", this, call);
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
}
