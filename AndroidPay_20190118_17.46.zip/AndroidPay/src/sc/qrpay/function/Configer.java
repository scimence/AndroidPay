
package sc.qrpay.function;

public class Configer
{
	private static String PayServerAddress = "";
	
	/** 获取服务器地址 */
	public static String ServerAddress()
	{
		if (PayServerAddress.equals(""))
		{
			String ConfigUrl = "https://scimence.gitee.io/config/files/config.txt";
			String data = WebTool.GetString(ConfigUrl);
			
			PayServerAddress = Tools.getNodeData(data, "QrPayServerAddress", false);
		}
		
		if(PayServerAddress.equals("")) return "www.scimence.club:8002";
		else return PayServerAddress;
	}
	
	/** 获取服务器指定页面地址 */
	public static String Url(String pageAddress, String param)
	{
		String url = "http://" + ServerAddress() + pageAddress;
		if(param!=null && !param.equals("")) url = url + "?" + param;
		return url;
	}
}
