package sc.qrpay.sdk;

import sc.qrpay.androidpay.PayPage;
import android.content.Context;


public class SDK
{
	public static CallBack call;
	public static Context context;
	
	/**
	 * 初始化
	 * @param context	上下文环境
	 * @param call		支付回调处理逻辑
	 */
	public static void Init(Context context, CallBack call)
	{
		SDK.context = context;
		SDK.call = call;
		
		PayPage.CheckPayResult(context);	// 调用支付开始,就开始进行支付结果检测
	}
	
	/** 调用支付
	 * @param context
	 * @param call			支付回调处理逻辑
	 * @param ProductName	商品名称
	 * @param ProductMoney	支付金额（元）， 如：1.99
	 * @param Reserve		自定义字段，查询支付结果时原样返还
	 * @param AppName		应用名称
	 * @param Author		应用所有者对应帐号名
	 */
	public static void Pay(String ProductName, String ProductMoney, String Reserve, String Author)
	{
		// SDK.call = call;
		PayPage.Show(context, ProductName, ProductMoney, Reserve, Author);
		
		// if (isInit)
		// {
		// PayCallBack = call;
		//
		// HashMap<String, String> payInfo = new HashMap<String, String>();
		// payInfo.put(PaymentKey.LtAppId, LtSDK.AppId);
		// payInfo.put(PaymentKey.LtJoyId, Login.uid);
		//
		// payInfo.put(PaymentKey.LtInstantId, ServerId);
		// payInfo.put(PaymentKey.LtReserve, Reserve);
		// payInfo.put(PaymentKey.MoneyAmount, ProductMoneyFen + "");
		// payInfo.put(PaymentKey.ProductId, productId);
		// payInfo.put(PaymentKey.ProductName, ProductName);
		// payInfo.put(PaymentKey.ProductDescript, ProductName);
		//
		// PayPage.ShowPay(context, payInfo);
		// }
		// else Tools.showText("调用支付前需先进行初始化Init()");
	}
	
}
