package sc.qrpay.function;

import java.text.DecimalFormat;

import sc.qrpay.function.ThreadTool.ThreadPram;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.telephony.TelephonyManager;
import android.widget.Toast;


/** Tools.java: */
public class Tools
{
	public static String TAG = "pay";

	/** 使用Toast显示信息 */
	public static void showToast(final Context context, final String info)
	{
		if(info.trim().equals("")) return;
		
		ThreadTool.RunInMainThread(new ThreadPram()
		{
			@Override
			public void Function()
			{
				Toast.makeText(context.getApplicationContext(), info, Toast.LENGTH_SHORT).show();
			}
		});
	}
	
	/** 将ProductMoney值，转化为两位精度串 */
	public static String FormatMoneyStr(String ProductMoney)
	{
		try
		{
			double MoneyAmount = Double.parseDouble(ProductMoney);
			
			DecimalFormat fnum = new DecimalFormat("##0.00");
			String moneyStr = fnum.format(MoneyAmount);
			
			return moneyStr;
		}
		catch (Exception ex)
		{
			return "0.00";
		}
	}

	/** 检测指定包名对应的应用是否已安装 */
	public static boolean isPkgInstalled(Context context, String pkgName)
	{
		if (context == null || pkgName == null || pkgName.equals("")) return false;
		
		try
		{
			PackageInfo packageInfo = context.getPackageManager().getPackageInfo(pkgName, 0);
			if (packageInfo != null) return true;
		}
		catch (Exception e)
		{
		}
		return false;
	}


	// 获取设备id
	private static String DeviceId = "";
	
	public static String getDeviceId(Context context)
	{
		if (!DeviceId.equals("")) return DeviceId;
		
		try
		{
			TelephonyManager manager = (TelephonyManager) context.getSystemService("phone");
			if (manager != null)
			{
				DeviceId = manager.getDeviceId();
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		
		return DeviceId;
	}

	// 获取acitivty所在的应用名称
	public static String getAppName(Context context)
	{
		PackageManager pm = context.getPackageManager();
		ApplicationInfo appInfo = context.getApplicationInfo();
		String appName = pm.getApplicationLabel(appInfo).toString();  // 获取当前游戏名称
		
		return appName;
	}
	
	// 获取acitivty所在的应用包名
	public static String getPackageName(Context context)
	{
		ApplicationInfo appInfo = context.getApplicationInfo();
		String packageName = appInfo.packageName;		// 获取当前游戏安装包名
		
		return packageName;
	}
	

    // 从自定义格式的数据data中，获取nodeName对应的节点数据
    //p>scimence(&#x000A;NeedToRegister(false)NeedToRegister&#x000A;RegisterPrice(1)RegisterPrice&#x000A;)scimence</p>&#x000A;</div>
    // NeedToRegister(false)&#x000A;RegisterPrice(1)   finalNode的数据格式
    public static String getNodeData(String data, String nodeName, boolean finalNode)
    {
        try
        {
        	String S = nodeName + "(", E = ")" + (finalNode ? "" : nodeName);
            int indexS = data.indexOf(S) + S.length();
            int indexE = data.indexOf(E, indexS);

            return data.substring(indexS, indexE);
        }
        catch (Exception ex) { return data; }
    }
}
