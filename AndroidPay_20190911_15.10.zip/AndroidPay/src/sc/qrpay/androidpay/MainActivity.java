
package sc.qrpay.androidpay;

import sc.qrpay.function.Tools;
import sc.qrpay.sdk.CallBack;
import sc.qrpay.sdk.SDK;
import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;


public class MainActivity extends Activity
{
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.pay_activity_main);
		
		SDK.Init(this, call);	// 初始化
	}
	
	CallBack call = new CallBack()
	{
		@Override
		public void OnSuccess(String ProductName, String ProductMoney, String Reserve)
		{
			Tools.showToast(MainActivity.this, "支付成功 " + "，ProductName -> " + ProductName + "，ProductMoney -> " + ProductMoney + "，Reserve -> " + Reserve);
		}
		
		@Override
		public void Onfail()
		{
			Tools.showToast(MainActivity.this, "支付失败" );
		}
	};
	
	public void onClick(View view)
	{
		SDK.Pay("ProductName", "0.03", "Reserve", "Author");	// 支付
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
}
