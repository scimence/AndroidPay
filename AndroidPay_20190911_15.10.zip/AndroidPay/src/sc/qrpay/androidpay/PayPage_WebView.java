
package sc.qrpay.androidpay;

import sc.qrpay.function.ActivityComponent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;


public class PayPage_WebView extends ActivityComponent
{
	String Url = "";
	
	/** 界面显示设置 */
	@Override
	public void Init(Bundle savedInstanceState)
	{
		this.setContentView("pay_alipay_alipay");
		
		// 载入web页信息
		Intent intent = this.getIntent();
		Url = intent.getStringExtra("Url");
		this.WebView("pay_alipay_webView").loadUrl(Url);
	}
	
	/** 界面控件点击响应逻辑 */
	@Override
	public void Click(String viewId)
	{	
		
	}
	
	// -----------
	
	/** 展示指定的web页 */
	public static void Show(Context context, String Url)
	{
		Intent intent = new Intent(context, PayPage_WebView.class);
		intent.putExtra("Url", Url);
		context.startActivity(intent);
	}
}
