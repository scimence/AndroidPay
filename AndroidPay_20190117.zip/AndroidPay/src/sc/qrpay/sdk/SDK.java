
package sc.qrpay.sdk;

import sc.qrpay.androidpay.PayPage;
import android.content.Context;


public class SDK
{
	public static Context context;
	public static CallBack call;
	
	/** 调用支付
	 * @param context
	 * @param call			支付回调处理逻辑
	 * @param ProductName	商品名称
	 * @param ProductMoney	支付金额（元）， 如：1.99
	 * @param Reserve		自定义字段，查询支付结果时原样返还
	 * @param AppName		应用名称
	 * @param Author		应用所有者对应帐号名
	 */
	public static void Pay(Context context, CallBack call, String ProductName, String ProductMoney, String Reserve, String AppName, String Author)
	{
		SDK.call = call;
		PayPage.Show(context, ProductName, ProductMoney, Reserve, AppName, Author);
		
		// if (isInit)
		// {
		// PayCallBack = call;
		//
		// HashMap<String, String> payInfo = new HashMap<String, String>();
		// payInfo.put(PaymentKey.LtAppId, LtSDK.AppId);
		// payInfo.put(PaymentKey.LtJoyId, Login.uid);
		//
		// payInfo.put(PaymentKey.LtInstantId, ServerId);
		// payInfo.put(PaymentKey.LtReserve, Reserve);
		// payInfo.put(PaymentKey.MoneyAmount, ProductMoneyFen + "");
		// payInfo.put(PaymentKey.ProductId, productId);
		// payInfo.put(PaymentKey.ProductName, ProductName);
		// payInfo.put(PaymentKey.ProductDescript, ProductName);
		//
		// PayPage.ShowPay(context, payInfo);
		// }
		// else Tools.showText("调用支付前需先进行初始化Init()");
	}
}
