
package sc.qrpay.sdk;

public interface CallBack
{
	// 成功
	public void OnSuccess();
	
	// 失败
	public void Onfail();
}
