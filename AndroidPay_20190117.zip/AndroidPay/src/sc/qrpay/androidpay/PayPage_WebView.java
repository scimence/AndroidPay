package sc.qrpay.androidpay;

import sc.qrpay.function.ActivityComponent;
import android.os.Bundle;

public class PayPage_WebView extends ActivityComponent
{	
	/** 界面显示设置 */
	@Override
	public void Init(Bundle savedInstanceState)
	{
		
	}
	
	/** 界面控件点击响应逻辑 */
	@Override
	public void Click(String viewId)
	{
		
	}
}
