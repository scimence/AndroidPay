
package sc.qrpay.androidpay;

import sc.qrpay.sdk.SDK;
import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;


public class MainActivity extends Activity
{
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.pay_activity_main);
	}
	
	public void onClick(View view)
	{
		SDK.Pay(this, null, "ProductName", "0.99", "Reserve", "AppName", "Author");
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
}
