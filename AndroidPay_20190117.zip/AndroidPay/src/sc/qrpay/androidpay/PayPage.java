
package sc.qrpay.androidpay;

import java.text.DecimalFormat;

import sc.qrpay.function.ActivityComponent;
import sc.qrpay.function.Preference;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;


public class PayPage extends ActivityComponent
{
	String ProductName;
	String ProductMoney;
	String Reserve;
	String AppName;
	String Author;
	
	int payType = 1;	// 记录当前选中的方式
	Preference localInfo;
	
	/** 界面显示设置 */
	@Override
	public void Init(Bundle savedInstanceState)
	{
		this.setContentView("pay_layout_pay");
		
		Intent intent = this.getIntent();
		ProductName = intent.getStringExtra("ProductName");
		ProductMoney = intent.getStringExtra("ProductMoney");
		Reserve = intent.getStringExtra("Reserve");
		AppName = intent.getStringExtra("AppName");
		Author = intent.getStringExtra("Author");
		
		setProductInfo();		// 设置显示的商品信息
		
		localInfo = new Preference(this, "LtAccountInfo");
		loadPrePayType();		// 设置支付类型
	}
	
	/** 界面控件点击响应逻辑 */
	@Override
	public void Click(String viewId)
	{
		if (viewId.equals("pay_more_paytype"))	// 更多支付方式
		{
			TextView("pay_more_paytype").setVisibility(View.INVISIBLE);
			LinearLayout("pay_iteam_others").setVisibility(View.VISIBLE);	// 显示其他支付方式
		}
		else if (viewId.equals("pay_btn"))
		{
			localInfo.put("LastPayType", payType + "");	// 记录当前选中的支付方式
			payLogic();		
		}
		else if (viewId.startsWith("pay_iteam") || viewId.startsWith("pay_radioButton"))
		{
			setPayType(viewId);
		}
	}
	
	/** 设置商品信息 */
	private void setProductInfo()
	{
		TextView("pay_app_name").setText(AppName);
		TextView("pay_product").setText(ProductName);
		TextView("pay_money").setText("￥ " + ProductMoney);
		
	}
	
	/** 载入之前的支付类型设置 */
	private void loadPrePayType()
	{
		String LastPayType = localInfo.get("LastPayType");
		if (!LastPayType.equals("")) payType = Integer.parseInt(LastPayType);
		
		setPayType(payType + "");	// 设置为对应的支付类型
		if (payType > 3) Click("pay_more_paytype");	// 显示更多支付类型
	}
	
	/** 设置当前选中的支付方式 */
	private void setPayType(String viewId)
	{
		for (int i = 1; i <= 6; i++)
		{
			boolean isSelect = (viewId.equals("pay_iteam" + i) || viewId.equals("pay_radioButton" + i) || viewId.equals(i + ""));
			
			RadioButton("pay_radioButton" + i).setChecked(isSelect);
			if (isSelect) payType = i;
		}
	}
	
	/** 支付逻辑 */
	private void payLogic()
	{	
		if(payType == 1)
		{
			if(isPkgInstalled(this, "com.eg.android.AlipayGphone"))
			{
				
			}
			else
			{
				
			}
		}
		else Toast.makeText(this, "暂不支持该支付方式！", Toast.LENGTH_SHORT).show();
	}
	
	// -----------
	
	/** 调用支付
	 * 
	 * @param context
	 * @param ProductName 商品名称
	 * @param ProductMoney 支付金额（元）， 如：1.99
	 * @param Reserve 自定义字段，查询支付结果时原样返还
	 * @param AppName 应用名称
	 * @param Author 应用所有者对应帐号名 */
	public static void Show(Context context, String ProductName, String ProductMoney, String Reserve, String AppName, String Author)
	{
		Intent intent = new Intent(context, PayPage.class);
		ProductMoney = FormatMoneyStr(ProductMoney);
		
		intent.putExtra("ProductName", ProductName);
		intent.putExtra("ProductMoney", ProductMoney);
		intent.putExtra("Reserve", Reserve);
		intent.putExtra("AppName", AppName);
		intent.putExtra("Author", Author);
		
		context.startActivity(intent);
	}
	
	/** 将ProductMoney值，转化为两位精度串 */
	public static String FormatMoneyStr(String ProductMoney)
	{
		try
		{
			double MoneyAmount = Double.parseDouble(ProductMoney);
			
			DecimalFormat fnum = new DecimalFormat("##0.00");
			String moneyStr = fnum.format(MoneyAmount);
			
			return moneyStr;
		}
		catch (Exception ex)
		{
			return "0.00";
		}
	}

	/** 检测指定包名对应的应用是否已安装 */
	public static boolean isPkgInstalled(Context context, String pkgName)
	{
		if (context == null || pkgName == null || pkgName.equals("")) return false;
		
		try
		{
			PackageInfo packageInfo = context.getPackageManager().getPackageInfo(pkgName, 0);
			if (packageInfo != null) return true;
		}
		catch (Exception e)
		{
		}
		return false;
	}
}
